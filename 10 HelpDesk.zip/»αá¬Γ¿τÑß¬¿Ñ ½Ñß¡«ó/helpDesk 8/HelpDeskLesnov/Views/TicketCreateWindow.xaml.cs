﻿using HelpDeskLesnov.Data;
using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace HelpDeskLesnov.Views
{
    public partial class TicketCreateWindow : Window
    {
        public TicketCreateWindow()
        {
            InitializeComponent();

            try
            {
                LoadCategories();
                LoadPriorities();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(
                    "Не удалось загрузить справочники из базы данных.\n\n" +
                    "Проверьте SQL Server, имя базы и строку подключения.\n\n" +
                    ex.Message,
                    "Ошибка базы данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        private void LoadCategories()
        {
            CategoryComboBox.Items.Clear();

            ComboBoxItem placeholder = new ComboBoxItem();
            placeholder.Content = "Выберите категорию";
            placeholder.IsEnabled = false;
            CategoryComboBox.Items.Add(placeholder);

            string sql = "SELECT Id, Name FROM Categories ORDER BY Name";

            using (SqlConnection connection = Database.GetConnection())
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ComboBoxItem item = new ComboBoxItem();
                        item.Content = reader["Name"].ToString();
                        item.Tag = Convert.ToInt32(reader["Id"]);

                        CategoryComboBox.Items.Add(item);
                    }
                }
            }

            CategoryComboBox.SelectedIndex = 0;
        }

        private void LoadPriorities()
        {
            PriorityComboBox.Items.Clear();

            string sql = @"
                SELECT Id, Name
                FROM Priorities
                ORDER BY SortOrder";

            using (SqlConnection connection = Database.GetConnection())
            using (SqlCommand command = new SqlCommand(sql, connection))
            {
                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        ComboBoxItem item = new ComboBoxItem();
                        item.Content = reader["Name"].ToString();
                        item.Tag = Convert.ToInt32(reader["Id"]);

                        PriorityComboBox.Items.Add(item);
                    }
                }
            }

            PriorityComboBox.SelectedIndex = -1;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (CategoryComboBox.SelectedIndex <= 0)
            {
                MessageBox.Show(
                    "Выберите категорию заявки.",
                    "Проверка данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            if (string.IsNullOrWhiteSpace(DescriptionTextBox.Text))
            {
                MessageBox.Show(
                    "Введите описание проблемы.",
                    "Проверка данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            if (PriorityComboBox.SelectedItem == null)
            {
                MessageBox.Show(
                    "Выберите приоритет заявки.",
                    "Проверка данных",
                    MessageBoxButton.OK,
                    MessageBoxImage.Warning);

                return;
            }

            MessageBox.Show(
                "Данные заявки заполнены корректно.\n\n" +
                "На следующих занятиях заявка будет сохраняться в MS SQL Server.",
                "HelpDesk",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
