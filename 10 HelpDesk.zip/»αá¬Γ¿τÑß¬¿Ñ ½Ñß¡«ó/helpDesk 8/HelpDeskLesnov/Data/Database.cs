﻿using System.Data.SqlClient;

namespace HelpDeskLesnov.Data
{
    public static class Database
    {
        public static string ConnectionString =
            @"Server=localhost\SQLEXPRESS;Database=HelpDesk_Lesnov;Trusted_Connection=True;TrustServerCertificate=True;";

        public static SqlConnection GetConnection()
        {
            return new SqlConnection(ConnectionString);
        }
    }
}
